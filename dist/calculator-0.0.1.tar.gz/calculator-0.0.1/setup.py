import setuptools

setuptools.setup(
    install_requires=[
        "Flask",
    ]
)