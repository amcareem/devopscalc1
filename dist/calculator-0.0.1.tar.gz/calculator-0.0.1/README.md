# SOLENTbcasDevOpsBCC629
This is the Solent University DevOps Group Project Repository. Participants are Ahamed Careem, Amsith Athambawa, Ahmath Musharraf and Nushath Nisardeen from BCAS campus
